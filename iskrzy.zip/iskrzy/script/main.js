$(function() {
    //        SCROLL TO
    $("a[href^='#']").on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $($(e.target).attr("href")).offset().top - 80
        }, 1000);
    });
    //        HIDE FB ICON
    var topOfOthDiv = $("#fbhide").offset().top;
    $(window).scroll(function() {
        if ($(window).scrollTop() > topOfOthDiv) {
            $("#fbic").hide();
        } else
            $("#fbic").show();
    });
    $("#mobile-menu-button").click(function() {
        $("#mobile-menu-button").toggleClass("active");
        $("#line-1").toggleClass("active");
        $("#line-2").toggleClass("active");
        $("#line-3").toggleClass("active");
        $("#mobile-menu").slideToggle("slow");
    });
    $(".off, section").click(function() {
        $("#mobile-menu-button").removeClass("active");
        $("#line-1").removeClass("active");
        $("#line-2").removeClass("active");
        $("#line-3").removeClass("active");
        $("#mobile-menu").slideUp("fast");
    });
    var mySwiper = new Swiper('.swiper-container', {
        // Optional parameters
        direction: 'horizontal',
        loop: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        autoplay: {
            delay: 5000,
        },
    })
});