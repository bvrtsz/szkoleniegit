    $(function () {
//        SCROLL TO
        $("a[href^='#']").on('click', function (e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $($(e.target).attr("href")).offset().top - 80
            }, 1000);
        });
//        HIDE FB ICON
        var topOfOthDiv = $("#fbhide").offset().top;
        $(window).scroll(function () {
            if ($(window).scrollTop() > topOfOthDiv) {
                $("#fbic").hide();
            }else   
                $("#fbic").show();
        });
    });
